# Student Course Registration System

1. Download **PIP** and **Python**
2. Open a terminal change your current directory to the source code folder path.
3. Execute the following commands:
    - pip install -r requirements.txt
    - python manage.py migrate
    - python manage.py runserver
4. Browse the system in your preferred browser.